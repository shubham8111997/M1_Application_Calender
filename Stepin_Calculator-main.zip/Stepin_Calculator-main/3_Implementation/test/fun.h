/**
 * @file fun.h
 * @brief 
 * 
 */
int addition();
int subtraction();
int multiplication();
int division();
int modulus();
int power();
int factorial();
int main();
