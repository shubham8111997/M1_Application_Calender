#include<stdio.h>
#include<math.h>
#include "fun.h"
int addition(int a, int b)
{
 return (a+b); //returning  result to main funtion 
}