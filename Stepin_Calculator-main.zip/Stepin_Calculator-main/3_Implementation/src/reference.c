void addition();
void subtraction();
void multiplication();
void division();
void modulus();
void power();
int factorial();