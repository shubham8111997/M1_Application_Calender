#include<stdio.h>
int modulus(int a,int b)
{
    
   return (a%b);//returning madules value to main funtion 
    
}