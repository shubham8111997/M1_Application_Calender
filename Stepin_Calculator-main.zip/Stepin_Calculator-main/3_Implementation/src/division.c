#include<stdio.h>
int division(int n1, int n2)
{
    
    return (n1/n2);
}