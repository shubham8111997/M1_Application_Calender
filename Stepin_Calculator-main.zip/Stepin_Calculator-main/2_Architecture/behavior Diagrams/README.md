# Behavior Diagrams
# Flow chart

![flow](https://user-images.githubusercontent.com/69413922/132313938-e1c9c26e-8ff9-48c0-a99c-0b43c36eed9b.png)    


# Sequence Diagram  

![sequ](https://user-images.githubusercontent.com/69413922/132314320-aa51bc80-b064-426d-b426-00aa928d859c.png)



