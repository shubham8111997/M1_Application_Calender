# Structure Diagrams

# Component Diagram   

# ![COMPON](https://user-images.githubusercontent.com/69413922/132314720-f109a6cb-ac57-428d-a173-14c869e54413.png)   
  
# Class Diagram  
# ![class (1)](https://user-images.githubusercontent.com/69413922/132315060-d77c79d6-5a87-4075-8f37-00111ef69d67.png)



