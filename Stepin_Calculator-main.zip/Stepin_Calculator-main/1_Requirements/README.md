# Calculator  

## Introduction:-   
Simple calculator is a project to allow users to calculate basic four operations in mathematics ,they are addition, subtraction, multiplication, division but in this Project
which I'm Implementing ,also included three additional operations such as Factorial, Power ,modulas .However, the input has to be in the form "number1 operator1 number2
"(i.e 2+4).    

The input includes the command such as we can give numbers based on the operation for example for addition we give 1 as a command and that particular operation works.Moreover, this calculator is smart enough to operate multiplication/division before addition/subtraction/factorial/power/modulas, in another word it is implemented with the
order of precedence logic.    

## Research:-  

https://www.programiz.com/c-programming/examples/calculator-switch-case  

https://www.knowprogram.com/c-programming/simple-calculator-program-c  

The switch-case statement is used to write a simple calculator program in C language. The remainder operator % is normally used with data values. To print the remainder
operator %% is used in the first printf() function. The variable ch store the operator, similarly the variables num1, and num2 stores the two
numbers. The switch has condition “ch” so the entered operator is matched with which case label those case label statements are executed, and display result to the screen. If the entered operator is not matched with the case labels then the default statement will be executed and it will display the message “Error! Invalid Operator.” to the screen.  

## Swot Analysis

 
**STRENGTHS**   
  
  
The ultimate strength Calculators is its innovative,user-friendly and long
lasting etc..    

**WEAKNESSES**  

do not inlude all the operations rather have onlty addition,subtraction
multiplication, division ,modulas ,power and factorial.    

**OPPORTUNITIES**    


The tech-based market has a huge opportunities in capturing the youth
market. And this calculator comparatively already one step ahead than
other    

**THREATS**  

The slower growth in technological innovation will also bring a significant
threat in the upcoming dynamic world.

## HIGH LEVEL REQUIREMENTS:-
| ID | Description | Category | 
| ----- | ----- | ------- | 
|HLR01|User should able to viewe operation list|technical|  
|HLR02|User should able to select the operation|technical|
|HLR03|The system sould able perform the given operation|technical|
|HLR04|The system should provide correct result|technical|   

## LOW LEVEL REQUIREMENTS:-
| ID | Description | Category | 
| ----- | ----- | ------- |



